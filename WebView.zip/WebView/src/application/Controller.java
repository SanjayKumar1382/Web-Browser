package application;

import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Iterator;
import java.util.ResourceBundle;

import javax.swing.text.TableView.TableRow;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Worker;
import javafx.concurrent.Worker.State;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class Controller implements Initializable{
	Stage stage = Main.stage;
	@FXML private WebView webview;
	static WebEngine engine;
	@FXML TextField urlfield;
	@FXML Label stateLabel;
	@FXML ProgressBar progress = new ProgressBar();
	
	
	@FXML TableView<History> table;
	@FXML AnchorPane pane;
	@FXML private TableColumn<History,String > title;
	@FXML private TableColumn<History,Date > date;	
	@FXML private TableColumn<History,String > 	url;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		engine = webview.getEngine();
		String ulrNext= "https://www.google.com/";
		engine.load(ulrNext);
		showUrl();
		
		Worker<Void> worker = engine.getLoadWorker();
		worker.stateProperty().addListener(new ChangeListener<State>() {

			@Override
			public void changed(ObservableValue<? extends State> arg0, State arg1, State arg2) {
				stateLabel.setText(""+arg2.toString());
				stateLabel.setTextFill(Color.RED);
				if(arg2==Worker.State.SUCCEEDED)
				{
					stage.setTitle(engine.getTitle());
					stateLabel.setText("Finish!");
					stateLabel.setTextFill(Color.GREEN);
				}
			}
		});
		progress.progressProperty().bind(worker.progressProperty());
		

	}
	public void btnGOclick(ActionEvent event)
	{
		String url = urlfield.getText();
		if(!url.contains("."))
		{
			String tempurl1="https://www.google.com/search?q=";
			String tempurl2 = "&cad=h";
			//gogle.com/#q=Tokyo+Disneyland+Rides
			System.out.println("hoiii");
			String temp[] = url.split(" ");
			int first = 1 ;
			for(String s : temp)
			{
				if(first==1)
				{
					tempurl1=tempurl1+s;
					first = 2;
				}
				else
					tempurl1=tempurl1+"+"+s;
			}
			url=tempurl1+tempurl2;
			System.out.println(url);
		}
		else
		{
			if(!url.contains("www.") && !url.contains("in."))
				url = "www."+url;
			if(!url.contains("https://"))
				url = "https://"+url;
		}
		engine.load(url);
		showUrl();
		
	}

	public void btn1click(ActionEvent event)
	{
		String ulrNext= "https://in.uc123.com/";
		engine.load(ulrNext);
		showUrl();
	}
/*
	public void btn2click(ActionEvent event)
	{
		engine.load("https://www.youtube.com");
		showUrl();
	}
	public void btn3click(ActionEvent event)
	{
		engine.load("https://www.facebook.com");
		showUrl();
	}
	public void btn4click(ActionEvent event)
	{
		engine.loadContent("<html>Hello world</html>");
		showUrl();
	}
*/
	public void btn5click(ActionEvent event)
	{
		engine.reload();
		showUrl();
	}
	public void btnBack(ActionEvent event)
	{
		WebHistory history = engine.getHistory();
		history.go(-1);
		showUrl();
	}
	public void btnFor(ActionEvent event)
	{
		WebHistory history = engine.getHistory();
		history.go( 1);
		showUrl();
	}
	
	public void keyGO(KeyEvent event)
	{
		KeyCode keyPressed = event.getCode();
		if(keyPressed.equals(KeyCode.ENTER))
			btnGOclick(new ActionEvent());		
	}
	public void showUrl(MouseEvent event)
	{
		String urlNext= engine.getLocation();
		urlfield.setText(urlNext);
		webview.setVisible(true);
		pane.setVisible(false);
	}
	public void history(MouseEvent event)
	{
		WebHistory history = engine.getHistory();
		ObservableList<WebHistory.Entry> entries = history.getEntries();
		History obj[] = new History[entries.size()];
		int ind = 0;
		ObservableList<History> list = FXCollections.observableArrayList();
		for(WebHistory.Entry entry : entries){
			//System.out.println("url : "+entry.getUrl()+" \ntitle "+entry.getTitle()+" \nlastVisitedDate"+entry.getLastVisitedDate());
			obj[ind] = new History(entry.getTitle(),entry.getLastVisitedDate(),entry.getUrl());
			list.add(obj[ind]);
		}
		title.setCellValueFactory(new PropertyValueFactory<History,String>("title"));
		date.setCellValueFactory(new PropertyValueFactory<History,Date>("date"));
		url.setCellValueFactory(new PropertyValueFactory<History,String>("url"));
		table.setItems(list);
		webview.setVisible(false);
		pane.setVisible(true);
		if(event.getClickCount()==2)
		{
			webview.setVisible(true);
			pane.setVisible(false);
		}
		
	}
	public void urlChooser(MouseEvent event)
	{
		if(event.getClickCount()==2)
		{
			History row = table.getSelectionModel().getSelectedItem();
			engine.load(row.url);
			showUrl();
		}
	}
	public void showUrl()
	{
		String urlNext= engine.getLocation();
		urlfield.setText(urlNext);
		webview.setVisible(true);
		pane.setVisible(false);
	}
	
}


package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

public class LoginController {
	
	@FXML	private Label status;
	@FXML	private TextField txtpass;
	@FXML	private TextField txtuser;
	public void login(ActionEvent event)
	{
		String enteredPass =txtpass.getText(); 
		String enteredUser =txtuser.getText(); 
		Connection myconn = Main.myconn;
		Statement stmt;
		int valid = 0;
		try 
		{
			stmt = myconn.createStatement();
			String sql="SELECT * FROM user where id= ? and pass=?";
			PreparedStatement pd = myconn.prepareStatement(sql);
			pd.setString(1, enteredUser);
			pd.setString(2, enteredPass);
			ResultSet res = pd.executeQuery();
			while(res.next())
				valid++;
		}
		catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		if(valid==1)
		{
			status.setText("Login Success");
			try {
				//Main.stage.hide();
				Stage primaryStage = Main.stage;
				Parent root = FXMLLoader.load(getClass().getResource("/application/fxmlfile.fxml"));
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		else
		{
			status.setText("Login Failed");
		}
	}
	public void keyLogin(KeyEvent event)
	{
		KeyCode keyPressed = event.getCode();
		if(keyPressed.equals(KeyCode.ENTER))
			login(new ActionEvent());		
	}
	public void registration(ActionEvent event)
	{
		try {
			Stage primaryStage = Main.stage;
	    	Parent root = FXMLLoader.load(getClass().getResource("/application/registeration.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}

package application;
import java.sql.*;
public class DBconnect {
	static Connection myconn;
	static
	{
		System.out.println("Database Connection is establishing");
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver"); 
			myconn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary","sanjay","1234");
			/*
			Statement stmt = myconn.createStatement();
			ResultSet res = stmt.executeQuery("SELECT * FROM employees");
			while(res.next())
			{
				System.out.println(res.getString("first_name")+" "+res.getString("last_name"));
			}
			//String sql = " insert into employees values (3,'yadav','himanshu','himanshu@gmail.com')";
			//stmt.executeUpdate(sql);
			System.out.println("insertion Complete : ->");
			res = stmt.executeQuery("SELECT * FROM employees where last_name='kumar'");
			while(res.next())
			{
				System.out.println(res.getString("first_name")+" "+res.getString("last_name"));
			}
			*/
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		System.out.println("Database Connected");
	}
}

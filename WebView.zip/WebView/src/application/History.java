package application;

import java.util.Date;

public class History
{
	String url;
	String title;
	Date date;
	public History( String title, Date date ,String url)
	{
		super();
		this.url = url;
		this.title = title;
		this.date = date;
	}
	public String getUrl() {
		return url;
	}
	public String getTitle() {
		return title;
	}
	public Date getDate() {
		return date;
	}
}

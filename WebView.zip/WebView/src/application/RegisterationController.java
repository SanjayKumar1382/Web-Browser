package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;

public class RegisterationController {
    @FXML	private Label status;
	@FXML	private TextField txtname;
	@FXML	private TextField txtuser;
	@FXML	private TextField txtemail;
	@FXML	private TextField txtpass;
	public void registeration(ActionEvent event)
	{
		String enteredName =txtname.getText(); 
		String enteredUser =txtuser.getText(); 
		String enteredEmail =txtemail.getText(); 
		String enteredPass =txtpass.getText(); 
		Connection myconn = Main.myconn;
		Statement stmt;
		int valid = 0;
		int errorName=0;
		int errorUser=-1;
		int errorEmail=0;
		int errorPass=0;
		try 
		{
			if(enteredName.equals(""))
			{
				status.setText("Enter valid name..");
				status.setTextFill(Color.RED);
				valid = 1;
			}	
			else if(enteredUser.equals(""))
			{
				status.setText("Enter valid Userid..");
				status.setTextFill(Color.RED);
				valid = 1;
				errorUser=1;
			}	
			else if(enteredEmail.equals(""))
			{
				status.setText("Enter valid Emaild..");
				status.setTextFill(Color.RED);
				valid = 1;
			}	
			else if(enteredPass.equals(""))
			{
				status.setText("Enter valid Password..");
				status.setTextFill(Color.RED);
				valid = 1;
			}
			if(errorUser==0)
			{
				stmt = myconn.createStatement();
				String sql="SELECT * FROM user where id= ?";
				PreparedStatement pd = myconn.prepareStatement(sql);
				pd.setString(1, enteredUser);
				ResultSet res = pd.executeQuery();
				while(res.next())
					valid++;
			}

		}
		catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		if(valid==0)
		{
			
			try 
			{
				stmt = myconn.createStatement();
				String sql="INSERT INTO user VALUES (?, ?, ?, ?)";
				PreparedStatement pd = myconn.prepareStatement(sql);
				pd.setString(1, enteredName);
				pd.setString(2, enteredUser);
				pd.setString(3, enteredPass);
				pd.setString(4, enteredEmail);
				pd.execute();
				status.setText("Registeration Success now log in");
				status.setTextFill(Color.GREEN);
			}
			catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		else
		{
//			status.setText("User already Exist");
//			status.setTextFill(Color.RED);
		}
	}
	public void keyLogin(KeyEvent event)
	{
		KeyCode keyPressed = event.getCode();
		if(keyPressed.equals(KeyCode.ENTER))
			registeration(new ActionEvent());		
	}
	public void login(ActionEvent event)
	{
		try {
			Stage primaryStage = Main.stage;
	    	Parent root = FXMLLoader.load(getClass().getResource("/application/login.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
